import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  person = {name: '', lastName: '', age: 0, married: true, country: 0};
  countries = [
    {
      id: 1,
      name: 'México'
    },
    {
      id: 2,
      name: 'Chile'
    },
    {
      id: 3,
      name: 'Colombia'
    },
    {
      id: 4,
      name: 'Ecuador'
    },
    {
      id: 5,
      name: 'Perú'
    },
    {
      id: 6,
      name: 'Argentina'
    },
    {
      id: 7,
      name: 'Uruguay'
    },
    {
      id: 8,
      name: 'Paraguay'
    },
    {
      id: 9,
      name: 'Venezuela'
    },
    {
      id: 10,
      name: 'Brasil'
    },
    {
      id: 11,
      name: 'Bolivia'
    },
    {
      id: 11,
      name: 'Costa Rica'
    },
  ];
  title = 'angular-forms-test';

  sendData(userForm: FormGroup): void {
    if (userForm.valid) {
      console.log(userForm);
      console.log(userForm.valid);
      console.log("valores a enviar", this.person)
    }
  }

  clearForm(userForm: FormGroup): void {
    userForm.reset();
  }
}
