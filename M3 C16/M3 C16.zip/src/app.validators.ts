import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";

export function customValidator(control: FormGroup): ValidationErrors | null {
    const textInput = control.value;
    const forbidden = /xavier/i.test(textInput);
    return forbidden ? null : {error_text: {value: control.value}};
}
