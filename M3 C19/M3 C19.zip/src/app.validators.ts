import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";

export function customValidator(control: FormGroup): ValidationErrors | null {
    const textInput = control.value;
    const forbidden = /xavier/i.test(textInput);
    return forbidden ? null : {error_text: {value: control.value}};
}

export function passwordValidator(controls: FormGroup): ValidationErrors  | null {
    const p1 = controls.get('password1')?.value;
    const p2 = controls.get('password2')?.value;
 
    return p1 === p2 ? null : {match_password: 'error_en_ los_passwords'}
}
