import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  implements OnInit{
  person = {name: '', lastName: '', age: 0, married: true, country: 0};
  countries = [
    {
      id: 1,
      name: 'México'
    },
    {
      id: 2,
      name: 'Chile'
    },
    {
      id: 3,
      name: 'Colombia'
    },
    {
      id: 4,
      name: 'Ecuador'
    },
    {
      id: 5,
      name: 'Perú'
    },
    {
      id: 6,
      name: 'Argentina'
    },
    {
      id: 7,
      name: 'Uruguay'
    },
    {
      id: 8,
      name: 'Paraguay'
    },
    {
      id: 9,
      name: 'Venezuela'
    },
    {
      id: 10,
      name: 'Brasil'
    },
    {
      id: 11,
      name: 'Bolivia'
    },
    {
      id: 11,
      name: 'Costa Rica'
    },
  ];
  title = 'angular-forms-test';
  customerName = new FormControl('Xavier Ramos');
  checkbox = new FormControl('');
  color = new FormControl('');
  date = new FormControl('');
  password = new FormControl('');
  phone = new FormControl();
  number = new FormControl();
  week = new FormControl();
  colorsObjField = new FormControl('');
  fruitsField = new FormControl();
 
  colors = [{
    id: '82bd0ab8-c58e-4639-b093-5da3710f8012',
    name: 'Khaki'
  }, {
    id: '7d776057-fab0-49f9-a45a-c79d0f8eb095',
    name: 'Red'
  }, {
    id: '29d684f9-73b3-4922-a38d-25df4b8921af',
    name: 'Pink'
  }, {
    id: '02993e09-16ca-4dd8-852f-1f41ae40a902',
    name: 'Aquamarine'
  }, {
    id: '87f28be4-7a98-4d4a-84f1-0d68e0a002d8',
    name: 'Mauv'
  }];
  fruits = ['Manzana', 'Naranja', 'Cereza', 'Mandarina', 'Platano', 'Fresa'];
  email = new FormControl('', [Validators.required, Validators.email]);
  form : FormGroup;

  constructor(
    private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      customerName: ['Xavier Ramos', Validators.required],
      color: ['', Validators.required],
      date: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
    });
  }


  ngOnInit(): void {
    this.customerName.valueChanges.subscribe(value => {
      console.log('Valor:', value);
    });
  }

  sendData(userForm: FormGroup): void {
    if (userForm.valid) {
      console.log(userForm);
      console.log(userForm.valid);
      console.log("valores a enviar", this.person)
    }
  }

  clearForm(userForm: FormGroup): void {
    userForm.reset();
  }

  get customerNameField(){
    return this.customerName;
  }

  get emailField() {
    return this.form.get('email');
  }

  sendDataReactive() {
    console.log(this.form.value);
  }

}
